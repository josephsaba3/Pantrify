const fs = require('node:fs');
const path = require('node:path');
const { stripTypeScriptTypes } = require('node:module');

const gameFiles = ['config', 'scoring', 'Tournament', 'MatchEngine', 'CourtRenderer', 'AudioEngine', 'MatchGame'];
function convert(file, testing = false) {
  let code = stripTypeScriptTypes(fs.readFileSync(file, 'utf8'), { mode: 'transform' });
  const exports = [...code.matchAll(/^export (?:const|function|class) (\w+)/gm)].map(match => match[1]);
  code = code.replace(/^import\s+\{([^}]+)\}\s+from\s+"[^"]+";\s*/gm, (_, names) => {
    if (testing && names.includes('describe')) return '';
    return `const {${names}} = window.RallyEleven;\n`;
  }).replace(/^import\s+[^;]+;\s*/gm, '').replace(/^export /gm, '');
  if (testing) code = 'const { assert, describe, it } = window.BrowserTests;\n' + code;
  const publish = exports.length ? `\nObject.assign(window.RallyEleven, { ${exports.join(', ')} });\n` : '';
  code = `// Plain browser JavaScript. Loaded in order by the HTML page.\n(() => {\n"use strict";\nwindow.RallyEleven ??= {};\n${code}${publish}})();\n`;
  fs.writeFileSync(file.replace(/\.ts$/, '.js'), code);
}
for (const name of gameFiles) convert(`src/game/${name}.ts`);
convert('src/main.ts');
for (const name of ['scoring', 'difficulty', 'tournament', 'physics']) convert(`tests/${name}.test.ts`, true);

fs.mkdirSync('assets/fonts', { recursive: true });
const distHtml = fs.readFileSync('dist/index.html', 'utf8');
const cssPath = distHtml.match(/href="\.\/(assets\/[^\"]+\.css)"/)[1];
const css = fs.readFileSync(path.join('dist', cssPath), 'utf8');
const fontRules = css.match(/@font-face\{[^}]+\}/g);
for (const rule of fontRules) {
  const name = rule.match(/url\(\.\/([^)]+)\)/)[1];
  fs.copyFileSync(path.join('dist/assets', name), path.join('assets/fonts', name));
}
fs.writeFileSync('assets/fonts.css', fontRules.join('\n').replaceAll('url(./', 'url(./fonts/') + '\n');

let html = fs.readFileSync('index.html', 'utf8');
html = html.replace('    <script type="module" src="/src/main.ts"></script>',
  [...gameFiles.map(name => `    <script defer src="./src/game/${name}.js"></script>`), '    <script defer src="./src/storage.js"></script>', '    <script defer src="./src/main.js"></script>'].join('\n'));
html = html.replace('  </head>', '    <link rel="stylesheet" href="./assets/fonts.css" />\n    <link rel="stylesheet" href="./src/styles.css" />\n  </head>');
fs.writeFileSync('index.html', html);
const main = fs.readFileSync('src/main.js', 'utf8').replaceAll('localStorage.', 'window.RallyEleven.storage.');
fs.writeFileSync('src/main.js', main);
const product = fs.readFileSync('PRODUCT.md', 'utf8').replace('Delegated: use a mobile-first TypeScript browser-game stack chosen for reliable touch controls, responsive rendering, and straightforward static deployment.', 'Plain JavaScript, HTML, CSS, and Canvas 2D. Open index.html directly or publish the files to static hosting. No Node, dependencies, build step, or application server is required.');
fs.writeFileSync('PRODUCT.md', product);
