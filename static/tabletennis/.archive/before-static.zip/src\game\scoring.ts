export type Side = "player" | "opponent";

export function opposite(side: Side): Side {
  return side === "player" ? "opponent" : "player";
}

export function hasWonGame(playerScore: number, opponentScore: number, target = 11): boolean {
  return Math.max(playerScore, opponentScore) >= target && Math.abs(playerScore - opponentScore) >= 2;
}

export function serverForPoint(totalPointsPlayed: number, openingServer: Side): Side {
  const serviceBlock = totalPointsPlayed >= 20 ? totalPointsPlayed - 20 : Math.floor(totalPointsPlayed / 2);
  const switches = totalPointsPlayed >= 20 ? 10 + serviceBlock : serviceBlock;
  return switches % 2 === 0 ? openingServer : opposite(openingServer);
}
