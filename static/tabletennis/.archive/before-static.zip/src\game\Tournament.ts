import type { DifficultyId } from "./config.ts";

export type RoundName = "Quarterfinal" | "Semifinal" | "Final";
export type TournamentStatus = "active" | "eliminated" | "champion";
export type OpponentStyle = "counter" | "spinner" | "smash" | "angle" | "wall";

export interface Competitor {
  id: string;
  name: string;
  code: string;
  seed: number;
  rating: number;
  color: string;
  style: OpponentStyle;
}

export interface TournamentMatch {
  id: string;
  round: RoundName;
  order: number;
  a: string;
  b: string;
  winnerId?: string;
  score?: string;
}

export interface TournamentSnapshot {
  difficultyId: DifficultyId;
  competitors: Competitor[];
  matches: TournamentMatch[];
  status: TournamentStatus;
}

const PLAYER: Competitor = {
  id: "player",
  name: "You",
  code: "YOU",
  seed: 1,
  rating: 88,
  color: "#ff5a36",
  style: "counter",
};

const OPPONENTS: readonly Omit<Competitor, "seed">[] = [
  { id: "mori", name: "Aiko Mori", code: "MOR", rating: 91, color: "#e9bd4b", style: "spinner" },
  { id: "vega", name: "Luz Vega", code: "VEG", rating: 86, color: "#e05b82", style: "angle" },
  { id: "okafor", name: "Nia Okafor", code: "OKA", rating: 89, color: "#54c79b", style: "smash" },
  { id: "rhee", name: "Min Rhee", code: "RHE", rating: 84, color: "#67b7e5", style: "counter" },
  { id: "novak", name: "Tomas Novak", code: "NOV", rating: 82, color: "#c6a3e8", style: "wall" },
  { id: "santos", name: "Ivo Santos", code: "SAN", rating: 79, color: "#f0964f", style: "angle" },
  { id: "carter", name: "Maya Carter", code: "CAR", rating: 76, color: "#8fc85b", style: "smash" },
] as const;

function seededScore(rng: () => number): string {
  const loser = Math.floor(rng() * 9);
  return `11–${loser}`;
}

export class Tournament {
  readonly difficultyId: DifficultyId;
  readonly competitors: Competitor[];
  matches: TournamentMatch[];
  status: TournamentStatus;
  private readonly rng: () => number;

  constructor(difficultyId: DifficultyId, rng: () => number = Math.random, snapshot?: TournamentSnapshot) {
    this.rng = rng;
    if (snapshot) {
      this.difficultyId = snapshot.difficultyId;
      this.competitors = snapshot.competitors;
      this.matches = snapshot.matches;
      this.status = snapshot.status;
      return;
    }

    this.difficultyId = difficultyId;
    this.competitors = [PLAYER, ...OPPONENTS.map((opponent, index) => ({ ...opponent, seed: index + 2 }))];
    this.status = "active";
    this.matches = [
      this.makeMatch("qf-1", "Quarterfinal", 0, "player", "carter"),
      this.makeMatch("qf-2", "Quarterfinal", 1, "rhee", "novak"),
      this.makeMatch("qf-3", "Quarterfinal", 2, "vega", "santos"),
      this.makeMatch("qf-4", "Quarterfinal", 3, "okafor", "mori"),
    ];
    this.simulateMatch(this.matches[1]);
    this.simulateMatch(this.matches[2]);
    this.simulateMatch(this.matches[3]);
  }

  static fromSnapshot(snapshot: TournamentSnapshot, rng: () => number = Math.random): Tournament {
    return new Tournament(snapshot.difficultyId, rng, snapshot);
  }

  private makeMatch(id: string, round: RoundName, order: number, a: string, b: string): TournamentMatch {
    return { id, round, order, a, b };
  }

  private competitor(id: string): Competitor {
    const found = this.competitors.find((competitor) => competitor.id === id);
    if (!found) throw new Error(`Unknown competitor: ${id}`);
    return found;
  }

  private simulateMatch(match: TournamentMatch): void {
    const a = this.competitor(match.a);
    const b = this.competitor(match.b);
    const chanceA = a.rating / (a.rating + b.rating);
    match.winnerId = this.rng() < chanceA ? a.id : b.id;
    match.score = seededScore(this.rng);
  }

  getRounds(): Record<RoundName, TournamentMatch[]> {
    return {
      Quarterfinal: this.matches.filter((match) => match.round === "Quarterfinal"),
      Semifinal: this.matches.filter((match) => match.round === "Semifinal"),
      Final: this.matches.filter((match) => match.round === "Final"),
    };
  }

  getCurrentPlayerMatch(): TournamentMatch | undefined {
    return this.matches.find(
      (match) => !match.winnerId && (match.a === PLAYER.id || match.b === PLAYER.id),
    );
  }

  getOpponent(match: TournamentMatch): Competitor {
    return this.competitor(match.a === PLAYER.id ? match.b : match.a);
  }

  recordPlayerResult(won: boolean, playerScore: number, opponentScore: number): void {
    const match = this.getCurrentPlayerMatch();
    if (!match) throw new Error("No active player match");
    const opponent = this.getOpponent(match);
    match.winnerId = won ? PLAYER.id : opponent.id;
    match.score = won ? `${playerScore}–${opponentScore}` : `${opponentScore}–${playerScore}`;

    if (!won) {
      this.status = "eliminated";
      return;
    }

    if (match.round === "Final") {
      this.status = "champion";
      return;
    }

    this.buildNextRound(match.round);
  }

  private buildNextRound(completedRound: RoundName): void {
    if (completedRound === "Quarterfinal") {
      const quarterfinals = this.getRounds().Quarterfinal;
      if (quarterfinals.some((match) => !match.winnerId)) return;
      const semifinals = [
        this.makeMatch("sf-1", "Semifinal", 0, quarterfinals[0].winnerId!, quarterfinals[1].winnerId!),
        this.makeMatch("sf-2", "Semifinal", 1, quarterfinals[2].winnerId!, quarterfinals[3].winnerId!),
      ];
      this.matches.push(...semifinals);
      const nonPlayerSemifinal = semifinals.find((match) => match.a !== PLAYER.id && match.b !== PLAYER.id);
      if (nonPlayerSemifinal) this.simulateMatch(nonPlayerSemifinal);
      return;
    }

    const semifinals = this.getRounds().Semifinal;
    if (semifinals.some((match) => !match.winnerId)) return;
    this.matches.push(this.makeMatch("final", "Final", 0, semifinals[0].winnerId!, semifinals[1].winnerId!));
  }

  serialize(): TournamentSnapshot {
    return {
      difficultyId: this.difficultyId,
      competitors: this.competitors,
      matches: this.matches,
      status: this.status,
    };
  }
}
