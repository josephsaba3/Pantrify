// Plain browser JavaScript. Loaded in order by the HTML page.
(() => {
"use strict";
window.RallyEleven ??= {};
const { hasWonGame, opposite, serverForPoint } = window.RallyEleven;
const TABLE_LENGTH = 2.74;
const TABLE_HALF_WIDTH = 0.7625;
const NET_Z = TABLE_LENGTH / 2;
const NET_HEIGHT = 0.1525;
const BALL_RADIUS = 0.02;
const PLAYER_PLANE = 0.075;
const OPPONENT_PLANE = TABLE_LENGTH - 0.075;
const GRAVITY = 9.81;
const PLAYER_CONTACT_RADIUS_X = 0.25;
const PLAYER_CONTACT_RADIUS_Y = 0.31;
const PLAYER_STRIKE_ZONE_FRONT = 0.24;
const PLAYER_STRIKE_ZONE_BACK = -0.09;
function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
}
function moveToward(current, target, maxDelta) {
    const delta = target - current;
    if (Math.abs(delta) <= maxDelta) return target;
    return current + Math.sign(delta) * maxDelta;
}
function closestPointOnSegment(pointX, pointY, startX, startY, endX, endY) {
    const segmentX = endX - startX;
    const segmentY = endY - startY;
    const lengthSquared = segmentX * segmentX + segmentY * segmentY;
    if (lengthSquared <= Number.EPSILON) return {
        x: endX,
        y: endY
    };
    const amount = clamp(((pointX - startX) * segmentX + (pointY - startY) * segmentY) / lengthSquared, 0, 1);
    return {
        x: startX + segmentX * amount,
        y: startY + segmentY * amount
    };
}
class MatchEngine {
    playerPaddle = {
        x: 0,
        y: 0.24,
        vx: 0,
        vy: 0
    };
    opponentPaddle = {
        x: 0,
        y: 0.25,
        vx: 0,
        vy: 0
    };
    ball = {
        x: 0,
        y: 0.3,
        z: 0.6,
        vx: 0,
        vy: 0,
        vz: 0,
        spin: 0,
        active: false
    };
    playerScore = 0;
    opponentScore = 0;
    totalPoints = 0;
    server = "player";
    waitingForServe = true;
    openingServer;
    difficulty;
    opponentStyle;
    rng;
    bouncesSinceHit = 0;
    lastHitter = "player";
    aiReactionClock = 0;
    aiTarget = {
        x: 0,
        y: 0.24
    };
    playerSweepStart = {
        x: 0,
        y: 0.24
    };
    constructor(difficulty, opponentStyle, roundPressure = 0, rng = Math.random){
        this.difficulty = {
            ...difficulty,
            reaction: Math.max(0.035, difficulty.reaction - roundPressure * 0.015),
            moveSpeed: difficulty.moveSpeed + roundPressure * 0.24,
            returnChance: Math.min(0.995, difficulty.returnChance + roundPressure * 0.012),
            shotSpeed: difficulty.shotSpeed + roundPressure * 0.16
        };
        this.opponentStyle = opponentStyle;
        this.rng = rng;
        this.openingServer = rng() > 0.5 ? "player" : "opponent";
        this.server = this.openingServer;
    }
    setPlayerPaddle(x, y, elapsedSeconds) {
        const dt = Math.max(1 / 120, Math.min(0.08, elapsedSeconds));
        const nextX = clamp(x, -0.86, 0.86);
        const nextY = clamp(y, 0.06, 0.72);
        const rawVx = (nextX - this.playerPaddle.x) / dt;
        const rawVy = (nextY - this.playerPaddle.y) / dt;
        this.playerPaddle.vx = this.playerPaddle.vx * 0.48 + rawVx * 0.52;
        this.playerPaddle.vy = this.playerPaddle.vy * 0.48 + rawVy * 0.52;
        this.playerPaddle.x = nextX;
        this.playerPaddle.y = nextY;
    }
    serve() {
        if (!this.waitingForServe) return;
        this.waitingForServe = false;
        this.ball.active = true;
        this.bouncesSinceHit = 0;
        this.lastHitter = this.server;
        const fromPlayer = this.server === "player";
        const paddle = fromPlayer ? this.playerPaddle : this.opponentPaddle;
        this.ball.x = paddle.x * 0.45;
        this.ball.y = 0.19;
        this.ball.z = fromPlayer ? 0.53 : TABLE_LENGTH - 0.53;
        this.ball.vx = (this.rng() - 0.5) * 0.28;
        this.ball.vy = 1.65;
        this.ball.vz = fromPlayer ? 3.55 : -3.55;
        this.ball.spin = 0;
        this.playerSweepStart.x = this.playerPaddle.x;
        this.playerSweepStart.y = this.playerPaddle.y;
    }
    update(dt) {
        const events = [];
        try {
            this.updateAI(dt);
            if (!this.ball.active) return events;
            const previous = {
                x: this.ball.x,
                y: this.ball.y,
                z: this.ball.z
            };
            this.ball.vx += this.ball.spin * this.ball.vz * 0.015 * dt;
            this.ball.vy -= GRAVITY * dt;
            this.ball.vx *= 1 - 0.025 * dt;
            this.ball.vz *= 1 - 0.012 * dt;
            this.ball.x += this.ball.vx * dt;
            this.ball.y += this.ball.vy * dt;
            this.ball.z += this.ball.vz * dt;
            const crossedNet = previous.z < NET_Z && this.ball.z >= NET_Z || previous.z > NET_Z && this.ball.z <= NET_Z;
            if (crossedNet && this.ball.y <= NET_HEIGHT + BALL_RADIUS) {
                this.awardPoint(opposite(this.lastHitter), "net", events);
                return events;
            }
            if (this.tryPaddleContact(previous, "player", events) || this.tryPaddleContact(previous, "opponent", events)) {
                return events;
            }
            if (previous.y > BALL_RADIUS && this.ball.y <= BALL_RADIUS) {
                const overTable = this.ball.z >= 0 && this.ball.z <= TABLE_LENGTH && Math.abs(this.ball.x) <= TABLE_HALF_WIDTH;
                if (!overTable) {
                    this.awardPoint(opposite(this.lastHitter), "wide", events);
                    return events;
                }
                const bounceSide = this.ball.z < NET_Z ? "player" : "opponent";
                const expectedSide = opposite(this.lastHitter);
                if (this.bouncesSinceHit === 0 && bounceSide !== expectedSide) {
                    this.awardPoint(opposite(this.lastHitter), "wrong side", events);
                    return events;
                }
                this.ball.y = BALL_RADIUS;
                this.ball.vy = Math.abs(this.ball.vy) * 0.88;
                this.ball.vx += this.ball.spin * 0.055;
                this.ball.spin *= 0.8;
                this.bouncesSinceHit += 1;
                events.push({
                    type: "table",
                    side: bounceSide
                });
                if (this.bouncesSinceHit >= 2) {
                    this.awardPoint(this.lastHitter, "second bounce", events);
                    return events;
                }
            }
            if (this.ball.z < -0.24) {
                this.awardPoint("opponent", "missed return", events);
            } else if (this.ball.z > TABLE_LENGTH + 0.24) {
                this.awardPoint("player", "missed return", events);
            } else if (this.ball.y < -0.4) {
                this.awardPoint(opposite(this.lastHitter), "out", events);
            }
            return events;
        } finally{
            this.playerSweepStart.x = this.playerPaddle.x;
            this.playerSweepStart.y = this.playerPaddle.y;
        }
    }
    tryPaddleContact(previous, side, events) {
        if (this.bouncesSinceHit !== 1) return false;
        const isPlayer = side === "player";
        const plane = isPlayer ? PLAYER_PLANE : OPPONENT_PLANE;
        const approaching = isPlayer ? this.ball.vz < 0 : this.ball.vz > 0;
        const crossed = isPlayer ? previous.z > plane && this.ball.z <= plane : previous.z < plane && this.ball.z >= plane;
        const insidePlayerStrikeZone = isPlayer && this.ball.z <= PLAYER_STRIKE_ZONE_FRONT && this.ball.z >= PLAYER_STRIKE_ZONE_BACK;
        if (!approaching || !crossed && !insidePlayerStrikeZone) return false;
        const paddle = isPlayer ? this.playerPaddle : this.opponentPaddle;
        const contactPoint = isPlayer ? closestPointOnSegment(this.ball.x, this.ball.y, this.playerSweepStart.x, this.playerSweepStart.y, paddle.x, paddle.y) : paddle;
        const dx = this.ball.x - contactPoint.x;
        const dy = this.ball.y - contactPoint.y;
        const hit = isPlayer ? (dx / PLAYER_CONTACT_RADIUS_X) ** 2 + (dy / PLAYER_CONTACT_RADIUS_Y) ** 2 <= 1 : Math.abs(dx) <= 0.185 && Math.abs(dy) <= 0.17;
        if (!hit) return false;
        if (!isPlayer && this.rng() > this.difficulty.returnChance) return false;
        if (isPlayer) this.playerReturn();
        else this.opponentReturn();
        this.bouncesSinceHit = 0;
        this.lastHitter = side;
        const power = Math.min(1.8, Math.hypot(paddle.vx, paddle.vy) * 0.08 + 0.75);
        events.push({
            type: "paddle",
            side,
            power
        });
        return true;
    }
    playerReturn() {
        const swipePower = clamp(Math.hypot(this.playerPaddle.vx, this.playerPaddle.vy) * 0.055, 0, 1.45);
        this.ball.z = PLAYER_PLANE;
        this.ball.vz = 3.75 + swipePower;
        this.ball.vy = clamp(2.05 + this.playerPaddle.vy * 0.035, 1.6, 3.25);
        this.ball.vx = clamp(this.playerPaddle.vx * 0.085 - this.playerPaddle.x * 0.42, -2.45, 2.45);
        this.ball.spin = clamp(this.playerPaddle.vx * 0.075, -1.45, 1.45);
    }
    opponentReturn() {
        const anticipatesPlayer = this.playerPaddle.x > 0 ? -1 : 1;
        const styleBias = this.opponentStyle === "angle" ? 1 : this.opponentStyle === "counter" ? 0.62 : 0.8;
        const targetX = clamp(anticipatesPlayer * this.difficulty.anticipation * styleBias * TABLE_HALF_WIDTH + (this.rng() - 0.5) * this.difficulty.aimError * 2, -TABLE_HALF_WIDTH * 0.92, TABLE_HALF_WIDTH * 0.92);
        const smashBoost = this.opponentStyle === "smash" && this.ball.y > 0.28 ? 0.5 : 0;
        const speed = this.difficulty.shotSpeed + smashBoost;
        const travelTime = TABLE_LENGTH / speed;
        this.ball.z = OPPONENT_PLANE;
        this.ball.vz = -speed;
        this.ball.vx = (targetX - this.ball.x) / travelTime;
        this.ball.vy = this.opponentStyle === "smash" ? 1.78 : 2.08 + this.rng() * 0.28;
        const spinDirection = this.opponentStyle === "spinner" ? 1.25 : 0.7;
        this.ball.spin = anticipatesPlayer * this.difficulty.spin * spinDirection;
    }
    updateAI(dt) {
        this.aiReactionClock += dt;
        if (this.ball.active && this.ball.vz > 0 && this.aiReactionClock >= this.difficulty.reaction) {
            this.aiReactionClock = 0;
            const predictionTime = Math.max(0, (OPPONENT_PLANE - this.ball.z) / Math.max(0.1, this.ball.vz));
            const forecast = this.difficulty.anticipation;
            const predictedX = this.ball.x + this.ball.vx * predictionTime * forecast;
            const predictedY = this.ball.y + this.ball.vy * predictionTime - 0.5 * GRAVITY * predictionTime * predictionTime;
            this.aiTarget.x = clamp(predictedX + (this.rng() - 0.5) * this.difficulty.aimError, -0.83, 0.83);
            this.aiTarget.y = clamp(predictedY, 0.08, 0.68);
        }
        const previousX = this.opponentPaddle.x;
        const previousY = this.opponentPaddle.y;
        this.opponentPaddle.x = moveToward(this.opponentPaddle.x, this.aiTarget.x, this.difficulty.moveSpeed * dt);
        this.opponentPaddle.y = moveToward(this.opponentPaddle.y, this.aiTarget.y, this.difficulty.moveSpeed * 0.72 * dt);
        this.opponentPaddle.vx = (this.opponentPaddle.x - previousX) / Math.max(dt, 0.001);
        this.opponentPaddle.vy = (this.opponentPaddle.y - previousY) / Math.max(dt, 0.001);
    }
    awardPoint(scorer, reason, events) {
        if (!this.ball.active) return;
        this.ball.active = false;
        if (scorer === "player") this.playerScore += 1;
        else this.opponentScore += 1;
        this.totalPoints += 1;
        events.push({
            type: "point",
            scorer,
            reason
        });
        if (hasWonGame(this.playerScore, this.opponentScore)) {
            events.push({
                type: "game",
                winner: this.playerScore > this.opponentScore ? "player" : "opponent"
            });
            this.waitingForServe = false;
            return;
        }
        this.server = serverForPoint(this.totalPoints, this.openingServer);
        this.waitingForServe = true;
    }
}

Object.assign(window.RallyEleven, { TABLE_LENGTH, TABLE_HALF_WIDTH, NET_Z, NET_HEIGHT, BALL_RADIUS, PLAYER_PLANE, MatchEngine });
})();
