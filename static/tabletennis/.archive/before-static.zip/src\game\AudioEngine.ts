export class AudioEngine {
  enabled = true;
  private context?: AudioContext;

  private ensureContext(): AudioContext | undefined {
    if (!this.enabled) return undefined;
    this.context ??= new AudioContext();
    if (this.context.state === "suspended") void this.context.resume();
    return this.context;
  }

  private tone(frequency: number, duration: number, volume: number, type: OscillatorType): void {
    const context = this.ensureContext();
    if (!context) return;
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    const now = context.currentTime;
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, now);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(60, frequency * 0.72), now + duration);
    gain.gain.setValueAtTime(volume, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    oscillator.connect(gain).connect(context.destination);
    oscillator.start(now);
    oscillator.stop(now + duration);
  }

  paddle(power = 1): void {
    this.tone(145 + power * 18, 0.065, 0.075, "triangle");
  }

  table(): void {
    this.tone(245, 0.038, 0.035, "sine");
  }

  point(won: boolean): void {
    this.tone(won ? 520 : 185, won ? 0.18 : 0.24, 0.05, won ? "sine" : "sawtooth");
  }

  toggle(): boolean {
    this.enabled = !this.enabled;
    return this.enabled;
  }
}
