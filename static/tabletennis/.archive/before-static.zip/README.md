# Rally Eleven

A phone-first table-tennis tournament game with direct paddle control, real first-to-11 scoring, four AI difficulty levels, and an eight-player knockout draw.

## Play locally

```powershell
npm install
npm run dev -- --host 0.0.0.0
```

Open the network URL printed by Vite on a phone connected to the same Wi-Fi. Landscape orientation gives the largest playing area; portrait is supported for menus.

This checkout is inside Google Drive. If Drive rejects dependency extraction with `EBADF` or `EPERM`, copy the project to a normal local folder such as `C:\Projects\rally-eleven`, install there, and keep this folder as the source backup.

## Controls

- Drag the paddle directly with a finger or mouse.
- Swipe through contact to add pace, direction, and side spin.
- Keyboard fallback: arrow keys move the paddle.
- Use **SND** to toggle generated sound and **Pause** to suspend a match.

## Tournament rules

- Eight-player single-elimination bracket.
- Quarterfinal, semifinal, and final.
- Each match is first to 11 and must be won by two points.
- Service changes every two points, then every point at deuce.
- A loss ends the current tournament run.

## Checks

```powershell
npm test
npm run build
npm run visual-check
```

`visual-check` uses an installed Chrome or Edge browser in headless mode and does not start a local server.
