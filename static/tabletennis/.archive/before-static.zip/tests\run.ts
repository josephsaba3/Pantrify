import "./scoring.test.ts";
import "./difficulty.test.ts";
import "./tournament.test.ts";
import "./physics.test.ts";
