import { access, mkdir, readdir } from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { chromium } from "playwright-core";

const projectRoot = path.resolve(import.meta.dirname, "..");
const distPath = path.join(projectRoot, "dist", "index.html");
const reviewDir = path.join(projectRoot, ".impeccable", "review");
const browserPaths = [
  "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
];

async function findBrowser() {
  for (const candidate of browserPaths) {
    try {
      await access(candidate);
      return candidate;
    } catch {
      // Try the next installed browser.
    }
  }
  throw new Error("No supported Chromium browser was found");
}

await mkdir(reviewDir, { recursive: true });
const executablePath = await findBrowser();
const browser = await chromium.launch({
  executablePath,
  headless: true,
  args: ["--allow-file-access-from-files", "--disable-gpu-sandbox"],
});

const errors = [];
const openPage = async (viewport) => {
  const page = await browser.newPage({ viewport, deviceScaleFactor: 1 });
  page.on("pageerror", (error) => errors.push(error.message));
  page.on("console", (message) => {
    if (message.type() === "error") errors.push(message.text());
  });
  await page.goto(pathToFileURL(distPath).href, { waitUntil: "load" });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: "load" });
  await page.waitForTimeout(250);
  return page;
};

const desktop = await openPage({ width: 1440, height: 900 });
await desktop.screenshot({ path: path.join(reviewDir, "desktop.png"), fullPage: true });
await desktop.locator("[data-new-tournament]").click();
await desktop.locator("[data-play]").click();
await desktop.waitForTimeout(150);
await desktop.screenshot({ path: path.join(reviewDir, "match-desktop.png"), fullPage: true });
await desktop.close();

const mobile = await openPage({ width: 390, height: 844 });
await mobile.screenshot({ path: path.join(reviewDir, "mobile.png"), fullPage: true });
await mobile.close();

const phone = await openPage({ width: 844, height: 390 });
await phone.locator("[data-new-tournament]").click();
await phone.waitForTimeout(120);
await phone.screenshot({ path: path.join(reviewDir, "bracket-phone.png"), fullPage: true });
await phone.locator("[data-play]").click();
await phone.waitForTimeout(150);
await phone.screenshot({ path: path.join(reviewDir, "phone-landscape.png"), fullPage: true });
await phone.locator("[data-serve]").click();
await phone.waitForTimeout(360);
await phone.screenshot({ path: path.join(reviewDir, "active-rally.png"), fullPage: true });
await phone.locator("[data-pause]").click();
if (!(await phone.locator("[data-resume]").isVisible())) errors.push("Pause menu did not open");
await phone.locator("[data-resume]").click();
if (await phone.locator("[data-resume]").isVisible()) errors.push("Pause menu did not close");
try {
  await phone.waitForFunction(() => {
    const player = Number(document.querySelector("[data-score-player]")?.textContent ?? "0");
    const opponent = Number(document.querySelector("[data-score-opponent]")?.textContent ?? "0");
    return player + opponent > 0;
  }, undefined, { timeout: 15000 });
  await phone.waitForTimeout(900);
  if (await phone.locator(".serve-overlay:not(.is-hidden)").isVisible()) {
    errors.push("Serve ticket repeated after the opening rally");
  }
} catch {
  errors.push("The first rally did not finish during the serve-flow check");
}
await phone.close();

await browser.close();

const captures = (await readdir(reviewDir)).filter((file) => file.endsWith(".png"));
console.log(`Captured: ${captures.join(", ")}`);
if (errors.length > 0) {
  console.error(errors.join("\n"));
  process.exitCode = 1;
}
