import type { Difficulty } from "./config.ts";
import { AudioEngine } from "./AudioEngine.ts";
import { CourtRenderer } from "./CourtRenderer.ts";
import { MatchEngine, type MatchEvent } from "./MatchEngine.ts";
import type { Competitor, RoundName } from "./Tournament.ts";

interface MatchGameOptions {
  opponent: Competitor;
  difficulty: Difficulty;
  round: RoundName;
  onComplete: (won: boolean, playerScore: number, opponentScore: number) => void;
  onForfeit: () => void;
}

function roundIndex(round: RoundName): number {
  if (round === "Quarterfinal") return 0;
  if (round === "Semifinal") return 1;
  return 2;
}

export class MatchGame {
  private readonly engine: MatchEngine;
  private readonly renderer: CourtRenderer;
  private readonly audio = new AudioEngine();
  private readonly canvas: HTMLCanvasElement;
  private readonly scorePlayer: HTMLElement;
  private readonly scoreOpponent: HTMLElement;
  private readonly serveOverlay: HTMLElement;
  private readonly pointCall: HTMLElement;
  private readonly pauseOverlay: HTMLElement;
  private animationFrame = 0;
  private previousFrame = performance.now();
  private lastPointerTime = performance.now();
  private paused = false;
  private complete = false;
  private rallyHasStarted = false;
  private pointTimer?: number;

  constructor(private readonly root: HTMLElement, private readonly options: MatchGameOptions) {
    this.root.innerHTML = `
      <section class="match-shell" aria-label="${options.round} against ${options.opponent.name}">
        <canvas class="court-canvas" aria-label="Interactive table-tennis court" tabindex="0"></canvas>
        <header class="score-ribbon">
          <div class="score-player score-side is-serving">
            <span class="competitor-mark" style="--mark: #ff5a36">YOU</span>
            <strong class="score-number" data-score-player>0</strong>
          </div>
          <div class="score-center">
            <span>${options.round}</span>
            <b>FIRST TO 11 · WIN BY 2</b>
          </div>
          <div class="score-player score-side">
            <strong class="score-number" data-score-opponent>0</strong>
            <span class="competitor-mark" style="--mark: ${options.opponent.color}">${options.opponent.code}</span>
          </div>
        </header>
        <div class="match-tools">
          <button class="square-control" type="button" data-sound aria-label="Sound is on; press to mute">SOUND ON</button>
          <button class="square-control" type="button" data-pause>PAUSE</button>
        </div>
        <div class="point-call" aria-live="polite"></div>
        <div class="serve-overlay">
          <div class="serve-ticket">
            <span>${options.difficulty.label} · ${options.opponent.style}</span>
            <strong data-serve-label>Open the rally</strong>
            <button class="primary-action" type="button" data-serve>Serve</button>
            <small>Drag the paddle. Swipe through contact for pace and spin.</small>
          </div>
        </div>
        <div class="pause-overlay" hidden>
          <div class="pause-panel">
            <strong>Match paused</strong>
            <button class="primary-action" type="button" data-resume>Resume</button>
            <button class="text-action" type="button" data-forfeit>Forfeit match</button>
          </div>
        </div>
      </section>
    `;

    this.canvas = this.requireElement<HTMLCanvasElement>("canvas");
    this.scorePlayer = this.requireElement("[data-score-player]");
    this.scoreOpponent = this.requireElement("[data-score-opponent]");
    this.serveOverlay = this.requireElement(".serve-overlay");
    this.pointCall = this.requireElement(".point-call");
    this.pauseOverlay = this.requireElement(".pause-overlay");
    this.engine = new MatchEngine(options.difficulty, options.opponent.style, roundIndex(options.round));
    this.renderer = new CourtRenderer(this.canvas);
    this.bindControls();
    this.updateServeUI();
    this.animationFrame = requestAnimationFrame(this.loop);
  }

  destroy(): void {
    cancelAnimationFrame(this.animationFrame);
    if (this.pointTimer) window.clearTimeout(this.pointTimer);
  }

  private requireElement<T extends HTMLElement = HTMLElement>(selector: string): T {
    const element = this.root.querySelector<T>(selector);
    if (!element) throw new Error(`Missing match element: ${selector}`);
    return element;
  }

  private bindControls(): void {
    this.canvas.addEventListener("pointerdown", (event) => {
      this.canvas.setPointerCapture(event.pointerId);
      this.movePaddle(event);
    });
    this.canvas.addEventListener("pointermove", (event) => {
      if (event.pointerType === "mouse" || this.canvas.hasPointerCapture(event.pointerId)) this.movePaddle(event);
    });
    this.canvas.addEventListener("keydown", (event) => {
      const keyMovement: Record<string, [number, number]> = {
        ArrowLeft: [-0.08, 0],
        ArrowRight: [0.08, 0],
        ArrowUp: [0, 0.06],
        ArrowDown: [0, -0.06],
      };
      const movement = keyMovement[event.key];
      if (!movement) return;
      event.preventDefault();
      this.engine.setPlayerPaddle(
        this.engine.playerPaddle.x + movement[0],
        this.engine.playerPaddle.y + movement[1],
        0.07,
      );
    });

    this.requireElement<HTMLButtonElement>("[data-serve]").addEventListener("click", () => {
      this.serveOverlay.classList.add("is-hidden");
      this.rallyHasStarted = true;
      this.engine.serve();
    });
    this.requireElement<HTMLButtonElement>("[data-pause]").addEventListener("click", () => this.setPaused(true));
    this.requireElement<HTMLButtonElement>("[data-resume]").addEventListener("click", () => this.setPaused(false));
    this.requireElement<HTMLButtonElement>("[data-forfeit]").addEventListener("click", () => {
      this.destroy();
      this.options.onForfeit();
    });
    this.requireElement<HTMLButtonElement>("[data-sound]").addEventListener("click", (event) => {
      const enabled = this.audio.toggle();
      const button = event.currentTarget as HTMLButtonElement;
      button.textContent = enabled ? "SOUND ON" : "SOUND OFF";
      button.setAttribute("aria-label", enabled ? "Sound is on; press to mute" : "Sound is off; press to enable");
    });
  }

  private movePaddle(event: PointerEvent): void {
    const now = performance.now();
    const position = this.renderer.screenToPaddle(event.clientX, event.clientY);
    this.engine.setPlayerPaddle(position.x, position.y, (now - this.lastPointerTime) / 1000);
    this.lastPointerTime = now;
  }

  private setPaused(paused: boolean): void {
    this.paused = paused;
    this.pauseOverlay.hidden = !paused;
    this.previousFrame = performance.now();
  }

  private readonly loop = (now: number): void => {
    const dt = Math.min(0.034, Math.max(0, (now - this.previousFrame) / 1000));
    this.previousFrame = now;
    if (!this.paused && !this.complete) {
      const events = this.engine.update(dt);
      this.handleEvents(events);
    }
    this.renderer.render(this.engine, dt);
    this.animationFrame = requestAnimationFrame(this.loop);
  };

  private handleEvents(events: MatchEvent[]): void {
    for (const event of events) {
      if (event.type === "paddle") {
        this.audio.paddle(event.power);
        if (event.side === "player") {
          this.renderer.flashContact();
          if (navigator.vibrate) navigator.vibrate(9);
        }
      }
      if (event.type === "table") this.audio.table();
      if (event.type === "point") this.handlePoint(event.scorer === "player", event.reason);
      if (event.type === "game") {
        this.complete = true;
        const won = event.winner === "player";
        this.pointTimer = window.setTimeout(() => {
          this.destroy();
          this.options.onComplete(won, this.engine.playerScore, this.engine.opponentScore);
        }, 1050);
      }
    }
  }

  private handlePoint(playerWon: boolean, reason: string): void {
    this.scorePlayer.textContent = String(this.engine.playerScore);
    this.scoreOpponent.textContent = String(this.engine.opponentScore);
    this.audio.point(playerWon);
    this.pointCall.textContent = `${playerWon ? "Your point" : `${this.options.opponent.code} point`} · ${reason}`;
    this.pointCall.classList.remove("is-visible");
    void this.pointCall.offsetWidth;
    this.pointCall.classList.add("is-visible");

    this.pointTimer = window.setTimeout(() => {
      if (!this.complete) this.updateServeUI();
    }, 760);
  }

  private updateServeUI(): void {
    if (!this.engine.waitingForServe) return;
    const playerServing = this.engine.server === "player";
    this.root.querySelectorAll(".score-side").forEach((element, index) => {
      element.classList.toggle("is-serving", playerServing ? index === 0 : index === 1);
    });

    if (this.rallyHasStarted) {
      this.serveOverlay.classList.add("is-hidden");
      this.engine.serve();
      return;
    }

    const label = this.requireElement("[data-serve-label]");
    const button = this.requireElement<HTMLButtonElement>("[data-serve]");
    label.textContent = playerServing ? "Your serve" : `${this.options.opponent.code} serves`;
    button.textContent = playerServing ? "Serve" : "Ready";
    this.serveOverlay.classList.remove("is-hidden");
  }
}
